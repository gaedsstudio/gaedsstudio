# SafeScan

Offline-first Android document scanner prototype built with Flutter 3.47.5.

Security goals:
- Release manifest explicitly removes INTERNET and common storage/network permissions.
- CAMERA is the only Android runtime permission allowed by CI verification.
- Standard scans export through Android SAF.
- Secure / ID PDFs are AES-256-GCM encrypted using a non-exportable Android Keystore key.
- FLAG_SECURE is enabled in Secure and ID modes.
- No account, ad, analytics, or crash-reporting SDK.

Implemented scanner features include camera capture, multi-page PDF creation, offline ML Kit OCR, searchable text layer, three filters, sensitive-pattern detection/redaction, encrypted secure storage, ID front/back one-page PDF with repeated watermark, auto-delete timers, document list, rename/delete/share, PIN lock, Korean/English UI, light/dark Material 3 UI.

Known scope note: automatic perspective edge detection/manual corner dragging is represented by the camera framing UI in this prototype and is not yet a full OpenCV-style quadrilateral editor.
