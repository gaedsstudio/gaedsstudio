import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final cameras = await availableCameras().catchError((_) => <CameraDescription>[]);
  runApp(SafeScanApp(prefs: prefs, cameras: cameras));
}

enum ScanMode { normal, secure, id }
enum ScanFilter { original, enhance, mono }

extension ScanModeX on ScanMode {
  String get key => name;
  String label(bool ko) => switch (this) {
        ScanMode.normal => ko ? '일반' : 'Standard',
        ScanMode.secure => ko ? '보안' : 'Secure',
        ScanMode.id => ko ? '신분증' : 'ID',
      };
  Color color(ColorScheme scheme) => switch (this) {
        ScanMode.normal => const Color(0xFF3B6EA8),
        ScanMode.secure => const Color(0xFF238B63),
        ScanMode.id => const Color(0xFFC98517),
      };
  IconData get icon => switch (this) {
        ScanMode.normal => Icons.document_scanner_outlined,
        ScanMode.secure => Icons.shield_outlined,
        ScanMode.id => Icons.badge_outlined,
      };
}

class SafeScanApp extends StatefulWidget {
  const SafeScanApp({super.key, required this.prefs, required this.cameras});
  final SharedPreferences prefs;
  final List<CameraDescription> cameras;
  @override
  State<SafeScanApp> createState() => _SafeScanAppState();
}

class _SafeScanAppState extends State<SafeScanApp> {
  late bool _ko;
  late bool _onboarded;
  bool _unlocked = false;

  @override
  void initState() {
    super.initState();
    _ko = widget.prefs.getString('lang') != 'en';
    _onboarded = widget.prefs.getBool('onboarded') ?? false;
  }

  @override
  Widget build(BuildContext context) {
    final seed = const Color(0xFF315F8E);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SafeScan',
      themeMode: ThemeMode.system,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF7F8FA),
        cardTheme: const CardThemeData(elevation: 0, margin: EdgeInsets.zero),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark),
      ),
      home: !_onboarded
          ? OnboardingScreen(
              ko: _ko,
              onDone: () async {
                await widget.prefs.setBool('onboarded', true);
                setState(() => _onboarded = true);
              },
            )
          : LockGate(
              prefs: widget.prefs,
              ko: _ko,
              bypass: _unlocked,
              onUnlocked: () => setState(() => _unlocked = true),
              child: HomeScreen(
                prefs: widget.prefs,
                cameras: widget.cameras,
                ko: _ko,
                onLanguageChanged: (value) async {
                  await widget.prefs.setString('lang', value ? 'ko' : 'en');
                  setState(() => _ko = value);
                },
              ),
            ),
    );
  }
}

class LockGate extends StatelessWidget {
  const LockGate({super.key, required this.prefs, required this.ko, required this.child, required this.bypass, required this.onUnlocked});
  final SharedPreferences prefs;
  final bool ko;
  final Widget child;
  final bool bypass;
  final VoidCallback onUnlocked;

  @override
  Widget build(BuildContext context) {
    final pin = prefs.getString('pin');
    if (pin == null || pin.isEmpty || bypass) return child;
    return PinScreen(ko: ko, expectedPin: pin, onSuccess: onUnlocked);
  }
}

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key, required this.ko, required this.onDone});
  final bool ko;
  final VoidCallback onDone;
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _controller = PageController();
  int page = 0;
  @override
  Widget build(BuildContext context) {
    final ko = widget.ko;
    final items = [
      (Icons.wifi_off_rounded, ko ? '인터넷 권한 없음' : 'No internet permission', ko ? '문서는 기기 밖으로 전송되지 않습니다. SafeScan은 네트워크 권한 없이 설계되었습니다.' : 'Your documents stay on the device. SafeScan is designed without network permission.'),
      (Icons.layers_outlined, ko ? '상황에 맞는 3가지 모드' : 'Three focused scan modes', ko ? '일반 문서는 빠르게, 민감 문서는 보안 모드로, 신분증은 전용 워터마크와 함께 처리합니다.' : 'Scan normal documents fast, redact sensitive data in Secure mode, and watermark IDs.'),
      (Icons.shield_moon_outlined, ko ? '보안 모드는 영구 가림' : 'Permanent secure redaction', ko ? '민감 정보는 이미지 픽셀 자체에 가림 처리되고 암호화되어 앱 내부에 보관됩니다.' : 'Sensitive regions are burned into pixels and encrypted inside the app.'),
    ];
    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          Expanded(
            child: PageView.builder(
              controller: _controller,
              itemCount: items.length,
              onPageChanged: (v) => setState(() => page = v),
              itemBuilder: (_, i) {
                final it = items[i];
                return Padding(
                  padding: const EdgeInsets.fromLTRB(28, 52, 28, 20),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Container(width: 76, height: 76, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(24)), child: Icon(it.$1, size: 38)),
                    const Spacer(),
                    Text(it.$2, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 14),
                    Text(it.$3, style: Theme.of(context).textTheme.bodyLarge?.copyWith(height: 1.5, color: Theme.of(context).colorScheme.onSurfaceVariant)),
                    const Spacer(),
                  ]),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 10, 24, 24),
            child: Row(children: [
              Row(children: List.generate(items.length, (i) => AnimatedContainer(duration: const Duration(milliseconds: 220), margin: const EdgeInsets.only(right: 6), width: i == page ? 24 : 8, height: 8, decoration: BoxDecoration(color: i == page ? Theme.of(context).colorScheme.primary : Theme.of(context).colorScheme.outlineVariant, borderRadius: BorderRadius.circular(10))))),
              const Spacer(),
              FilledButton.icon(
                onPressed: page == items.length - 1 ? widget.onDone : () => _controller.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeOutCubic),
                icon: Icon(page == items.length - 1 ? Icons.check_rounded : Icons.arrow_forward_rounded),
                label: Text(page == items.length - 1 ? (ko ? '시작하기' : 'Get started') : (ko ? '다음' : 'Next')),
              ),
            ]),
          )
        ]),
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.prefs, required this.cameras, required this.ko, required this.onLanguageChanged});
  final SharedPreferences prefs;
  final List<CameraDescription> cameras;
  final bool ko;
  final ValueChanged<bool> onLanguageChanged;
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class DocItem {
  DocItem({required this.id, required this.name, required this.mode, required this.createdAt, required this.path, required this.encrypted});
  final String id, name, path;
  final ScanMode mode;
  final DateTime createdAt;
  final bool encrypted;
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'mode': mode.name, 'createdAt': createdAt.toIso8601String(), 'path': path, 'encrypted': encrypted};
  static DocItem fromJson(Map<String, dynamic> j) => DocItem(id: j['id'], name: j['name'], mode: ScanMode.values.byName(j['mode']), createdAt: DateTime.parse(j['createdAt']), path: j['path'], encrypted: j['encrypted'] ?? false);
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  List<DocItem> docs = [];
  ScanMode? filter;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    final raw = widget.prefs.getStringList('docs') ?? [];
    setState(() => docs = raw.map((e) => DocItem.fromJson(jsonDecode(e))).toList()..sort((a,b) => b.createdAt.compareTo(a.createdAt)));
    _purgeExpired();
  }

  Future<void> _purgeExpired() async {
    final now = DateTime.now();
    final timers = widget.prefs.getString('expiryMap');
    if (timers == null) return;
    final map = Map<String, dynamic>.from(jsonDecode(timers));
    final expired = <String>[];
    map.forEach((id, iso) { if (DateTime.tryParse('$iso')?.isBefore(now) ?? false) expired.add(id); });
    if (expired.isEmpty) return;
    for (final d in docs.where((d) => expired.contains(d.id))) { try { await File(d.path).delete(); } catch (_) {} }
    docs.removeWhere((d) => expired.contains(d.id));
    for (final id in expired) { map.remove(id); }
    await _saveDocs();
    await widget.prefs.setString('expiryMap', jsonEncode(map));
    if (mounted) setState(() {});
  }

  Future<void> _saveDocs() => widget.prefs.setStringList('docs', docs.map((e) => jsonEncode(e.toJson())).toList());

  @override
  Widget build(BuildContext context) {
    final ko = widget.ko;
    return Scaffold(
      body: IndexedStack(index: tab, children: [
        SafeArea(child: Column(children: [
          Padding(padding: const EdgeInsets.fromLTRB(20, 16, 12, 12), child: Row(children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('SafeScan', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900, letterSpacing: -0.5)),
              Text(ko ? '오프라인 문서 보관함' : 'Offline document vault', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant)),
            ]),
            const Spacer(),
            IconButton(onPressed: () => setState(() => tab = 1), icon: const Icon(Icons.settings_outlined))
          ])),
          SizedBox(height: 42, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
            FilterChip(label: Text(ko ? '전체' : 'All'), selected: filter == null, onSelected: (_) => setState(() => filter = null)),
            const SizedBox(width: 8),
            ...ScanMode.values.map((m) => Padding(padding: const EdgeInsets.only(right: 8), child: FilterChip(avatar: Icon(m.icon, size: 18, color: m.color(Theme.of(context).colorScheme)), label: Text(m.label(ko)), selected: filter == m, onSelected: (_) => setState(() => filter = m)))),
          ])),
          const SizedBox(height: 12),
          Expanded(child: _docList(context)),
        ])),
        SettingsScreen(prefs: widget.prefs, ko: ko, onBack: () => setState(() => tab = 0), onLanguageChanged: widget.onLanguageChanged),
      ]),
      floatingActionButton: tab == 0 ? FloatingActionButton.extended(onPressed: _openScanner, icon: const Icon(Icons.document_scanner_outlined), label: Text(ko ? '스캔' : 'Scan')) : null,
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }

  Widget _docList(BuildContext context) {
    final visible = docs.where((d) => filter == null || d.mode == filter).toList();
    if (visible.isEmpty) {
      return Center(child: Padding(padding: const EdgeInsets.all(36), child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.snippet_folder_outlined, size: 56, color: Theme.of(context).colorScheme.outline),
        const SizedBox(height: 14),
        Text(widget.ko ? '아직 스캔한 문서가 없습니다' : 'No scanned documents yet', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Text(widget.ko ? '아래 스캔 버튼으로 첫 문서를 만들어보세요.' : 'Use the scan button below to create your first document.', textAlign: TextAlign.center, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
      ])));
    }
    return ListView.separated(padding: const EdgeInsets.fromLTRB(16, 0, 16, 100), itemCount: visible.length, separatorBuilder: (_, __) => const SizedBox(height: 10), itemBuilder: (_, i) {
      final d = visible[i];
      return Card(child: ListTile(contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8), leading: Container(width: 50, height: 58, decoration: BoxDecoration(color: d.mode.color(Theme.of(context).colorScheme).withValues(alpha: .12), borderRadius: BorderRadius.circular(12)), child: Icon(d.mode.icon, color: d.mode.color(Theme.of(context).colorScheme))), title: Text(d.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text('${d.mode.label(widget.ko)} · ${_date(d.createdAt)}${d.encrypted ? ' · AES' : ''}'), trailing: PopupMenuButton<String>(onSelected: (v) => _docAction(v, d), itemBuilder: (_) => [PopupMenuItem(value: 'share', child: Text(widget.ko ? '공유' : 'Share')), PopupMenuItem(value: 'rename', child: Text(widget.ko ? '이름 변경' : 'Rename')), PopupMenuItem(value: 'delete', child: Text(widget.ko ? '삭제' : 'Delete'))])));
    });
  }

  String _date(DateTime d) => '${d.year}.${d.month.toString().padLeft(2,'0')}.${d.day.toString().padLeft(2,'0')} ${d.hour.toString().padLeft(2,'0')}:${d.minute.toString().padLeft(2,'0')}';

  Future<void> _openScanner() async {
    final result = await Navigator.of(context).push<DocItem>(MaterialPageRoute(builder: (_) => ScannerScreen(cameras: widget.cameras, ko: widget.ko, prefs: widget.prefs)));
    if (result != null) { docs.insert(0, result); await _saveDocs(); if (mounted) setState(() {}); }
  }

  Future<void> _docAction(String action, DocItem d) async {
    if (action == 'delete') {
      try { await File(d.path).delete(); } catch (_) {}
      docs.removeWhere((e) => e.id == d.id); await _saveDocs(); if (mounted) setState(() {}); return;
    }
    if (action == 'rename') {
      final c = TextEditingController(text: d.name);
      final name = await showDialog<String>(context: context, builder: (_) => AlertDialog(title: Text(widget.ko ? '이름 변경' : 'Rename'), content: TextField(controller: c, autofocus: true), actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text(widget.ko ? '취소' : 'Cancel')), FilledButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: Text(widget.ko ? '저장' : 'Save'))]));
      if (name != null && name.isNotEmpty) { final idx = docs.indexWhere((e) => e.id == d.id); docs[idx] = DocItem(id:d.id,name:name,mode:d.mode,createdAt:d.createdAt,path:d.path,encrypted:d.encrypted); await _saveDocs(); if (mounted) setState(() {}); } return;
    }
    if (action == 'share') {
      Uint8List bytes = await File(d.path).readAsBytes();
      if (d.encrypted) { bytes = await NativeBridge.decrypt(bytes); }
      await NativeBridge.sharePdf(bytes, '${d.name}.pdf');
    }
  }
}

class ScannerScreen extends StatefulWidget {
  const ScannerScreen({super.key, required this.cameras, required this.ko, required this.prefs});
  final List<CameraDescription> cameras;
  final bool ko;
  final SharedPreferences prefs;
  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class CapturedPage {
  CapturedPage(this.path, this.ocrText);
  String path;
  String ocrText;
}

class _ScannerScreenState extends State<ScannerScreen> {
  CameraController? controller;
  ScanMode mode = ScanMode.normal;
  ScanFilter filter = ScanFilter.original;
  final pages = <CapturedPage>[];
  bool busy = false;
  int idSide = 0;
  String watermark = '';
  String expiry = 'off';

  @override
  void initState() { super.initState(); _init(); }
  Future<void> _init() async {
    if (widget.cameras.isEmpty) return;
    final back = widget.cameras.firstWhere((c) => c.lensDirection == CameraLensDirection.back, orElse: () => widget.cameras.first);
    final c = CameraController(back, ResolutionPreset.high, enableAudio: false);
    try { await c.initialize(); if (mounted) setState(() => controller = c); } catch (_) { await c.dispose(); }
  }

  @override
  void dispose() { controller?.dispose(); NativeBridge.setSecure(false); super.dispose(); }

  Future<void> _setMode(ScanMode m) async {
    setState(() { mode = m; if (m != ScanMode.id) idSide = 0; });
    await NativeBridge.setSecure(m != ScanMode.normal);
  }

  @override
  Widget build(BuildContext context) {
    final c = controller;
    final accent = mode.color(Theme.of(context).colorScheme);
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onHorizontalDragEnd: (d) {
          final v = d.primaryVelocity ?? 0;
          final i = mode.index + (v < 0 ? 1 : -1);
          if (i >= 0 && i < ScanMode.values.length) _setMode(ScanMode.values[i]);
        },
        child: Stack(fit: StackFit.expand, children: [
          if (c != null && c.value.isInitialized) Center(child: CameraPreview(c)) else const Center(child: CircularProgressIndicator()),
          Container(decoration: BoxDecoration(border: Border.all(color: accent, width: 3))),
          SafeArea(child: Column(children: [
            Padding(padding: const EdgeInsets.fromLTRB(12, 6, 12, 0), child: Row(children: [
              IconButton.filledTonal(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded)),
              const Spacer(),
              Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), decoration: BoxDecoration(color: Colors.black.withValues(alpha:.55), borderRadius: BorderRadius.circular(99), border: Border.all(color: accent.withValues(alpha:.9))), child: Row(children: [Icon(mode.icon, size:18, color:accent), const SizedBox(width:6), Text(mode.label(widget.ko), style: const TextStyle(color:Colors.white,fontWeight:FontWeight.w700))])),
              const Spacer(),
              IconButton.filledTonal(onPressed: () => _showOptions(), icon: const Icon(Icons.tune_rounded)),
            ])),
            const Spacer(),
            if (mode == ScanMode.id) Container(margin: const EdgeInsets.symmetric(horizontal: 24), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.black.withValues(alpha:.55), borderRadius: BorderRadius.circular(14)), child: Row(children:[Icon(idSide==0?Icons.looks_one_outlined:Icons.looks_two_outlined,color:Colors.white),const SizedBox(width:8),Expanded(child:Text(idSide==0?(widget.ko?'신분증 앞면을 프레임에 맞춰주세요':'Align the front of the ID'):(widget.ko?'이제 뒷면을 촬영하세요':'Now capture the back'),style:const TextStyle(color:Colors.white,fontWeight:FontWeight.w600)))])),
            const SizedBox(height: 16),
            _modeBar(accent),
            const SizedBox(height: 16),
            Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              _roundButton(Icons.photo_library_outlined, pages.isEmpty ? '' : '${pages.length}', onTap: pages.isEmpty ? null : _reviewPages),
              GestureDetector(onTap: busy ? null : _capture, child: AnimatedContainer(duration: const Duration(milliseconds:160), width: 82, height: 82, decoration: BoxDecoration(shape:BoxShape.circle,border:Border.all(color:Colors.white,width:5),color:busy?Colors.white24:accent), child: busy ? const Padding(padding:EdgeInsets.all(24),child:CircularProgressIndicator(color:Colors.white,strokeWidth:3)) : const Icon(Icons.camera_alt_rounded,color:Colors.white,size:34))),
              _roundButton(Icons.check_rounded, '', onTap: pages.isEmpty || busy ? null : _finish),
            ]),
            const SizedBox(height: 26),
          ])),
        ]),
      ),
    );
  }

  Widget _modeBar(Color accent) => Container(margin: const EdgeInsets.symmetric(horizontal: 20), padding: const EdgeInsets.all(4), decoration: BoxDecoration(color: Colors.black.withValues(alpha:.58), borderRadius: BorderRadius.circular(18)), child: Row(children: ScanMode.values.map((m) { final selected = m==mode; return Expanded(child: InkWell(borderRadius:BorderRadius.circular(14),onTap:()=>_setMode(m),child:AnimatedContainer(duration:const Duration(milliseconds:180),padding:const EdgeInsets.symmetric(vertical:10),decoration:BoxDecoration(color:selected?m.color(Theme.of(context).colorScheme):Colors.transparent,borderRadius:BorderRadius.circular(14)),child:Text(m.label(widget.ko),textAlign:TextAlign.center,style:TextStyle(color:Colors.white,fontWeight:selected?FontWeight.w800:FontWeight.w600))))); }).toList()));
  Widget _roundButton(IconData icon, String badge, {VoidCallback? onTap}) => GestureDetector(onTap:onTap, child:Stack(clipBehavior:Clip.none,children:[Container(width:52,height:52,decoration:BoxDecoration(color:onTap==null?Colors.white12:Colors.black54,shape:BoxShape.circle,border:Border.all(color:Colors.white24)),child:Icon(icon,color:onTap==null?Colors.white30:Colors.white)),if(badge.isNotEmpty)Positioned(right:-4,top:-4,child:Container(padding:const EdgeInsets.symmetric(horizontal:6,vertical:2),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(12)),child:Text(badge,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:11))))]));

  Future<void> _capture() async {
    final c = controller; if (c == null || !c.value.isInitialized) return;
    setState(() => busy = true);
    try {
      final shot = await c.takePicture();
      final processed = await ScanProcessor.process(shot.path, mode: mode, filter: filter);
      pages.add(CapturedPage(processed.path, processed.ocrText));
      if (mode == ScanMode.id && idSide == 0) setState(() => idSide = 1);
      else if (mounted) setState(() {});
      if (mode == ScanMode.normal && processed.sensitiveFound && mounted) {
        final yes = await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:Text(widget.ko?'민감 정보가 감지되었습니다':'Sensitive data detected'),content:Text(widget.ko?'보안 모드로 전환할까요? 현재 촬영본은 일반 모드 상태입니다.':'Switch to Secure mode? The current capture remains a standard scan.'),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:Text(widget.ko?'유지':'Keep')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:Text(widget.ko?'보안 모드':'Secure mode'))]));
        if (yes==true) _setMode(ScanMode.secure);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${widget.ko?'촬영 실패':'Capture failed'}: $e')));
    } finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> _finish() async {
    setState(()=>busy=true);
    try {
      if (mode==ScanMode.id && pages.length<2) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(widget.ko?'앞면과 뒷면을 모두 촬영하세요.':'Capture both front and back.'))); return; }
      final bytes = await ScanProcessor.buildPdf(pages, mode:mode, watermark:watermark, ko:widget.ko);
      final now = DateTime.now();
      final name = mode==ScanMode.id ? 'ID_${now.year}${now.month.toString().padLeft(2,'0')}${now.day.toString().padLeft(2,'0')}' : 'Scan_${now.year}${now.month.toString().padLeft(2,'0')}${now.day.toString().padLeft(2,'0')}_${now.hour.toString().padLeft(2,'0')}${now.minute.toString().padLeft(2,'0')}';
      late File saved;
      bool encrypted = mode != ScanMode.normal;
      final dir = await getApplicationDocumentsDirectory();
      final id = now.microsecondsSinceEpoch.toString();
      if (encrypted) {
        final enc = await NativeBridge.encrypt(bytes); saved = File('${dir.path}/$id.ssenc'); await saved.writeAsBytes(enc, flush:true);
        if (expiry!='off') {
          final map = Map<String,dynamic>.from(jsonDecode(widget.prefs.getString('expiryMap') ?? '{}'));
          final duration = switch(expiry){'1h'=>const Duration(hours:1),'24h'=>const Duration(hours:24),'7d'=>const Duration(days:7),_=>Duration.zero};
          map[id]=now.add(duration).toIso8601String(); await widget.prefs.setString('expiryMap', jsonEncode(map));
        }
      } else {
        saved = File('${dir.path}/$id.pdf'); await saved.writeAsBytes(bytes,flush:true);
        await NativeBridge.savePdf(bytes,'$name.pdf');
      }
      if (mounted) Navigator.pop(context, DocItem(id:id,name:name,mode:mode,createdAt:now,path:saved.path,encrypted:encrypted));
    } catch(e) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('${widget.ko?'PDF 생성 실패':'PDF creation failed'}: $e'))); }
    finally { if(mounted) setState(()=>busy=false); }
  }

  Future<void> _showOptions() async {
    await showModalBottomSheet(context:context,isScrollControlled:true,builder:(ctx)=>StatefulBuilder(builder:(ctx,setSheet)=>Padding(padding:EdgeInsets.fromLTRB(20,16,20,20+MediaQuery.of(ctx).viewInsets.bottom),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(widget.ko?'스캔 옵션':'Scan options',style:Theme.of(ctx).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.w800)),const SizedBox(height:16),
      Text(widget.ko?'필터':'Filter',style:const TextStyle(fontWeight:FontWeight.w700)),const SizedBox(height:8),SegmentedButton<ScanFilter>(segments:[ButtonSegment(value:ScanFilter.original,label:Text(widget.ko?'원본':'Original')),ButtonSegment(value:ScanFilter.enhance,label:Text(widget.ko?'선명하게':'Enhance')),ButtonSegment(value:ScanFilter.mono,label:Text(widget.ko?'흑백':'B&W'))],selected:{filter},onSelectionChanged:(s){setState(()=>filter=s.first);setSheet((){});}),
      if(mode==ScanMode.id)...[const SizedBox(height:16),TextField(decoration:InputDecoration(labelText:widget.ko?'워터마크 용도 문구':'Watermark purpose',hintText:widget.ko?'예: ABC 은행 제출용':'e.g. For ABC Bank'),onChanged:(v)=>watermark=v)],
      if(mode!=ScanMode.normal)...[const SizedBox(height:16),DropdownButtonFormField<String>(value:expiry,decoration:InputDecoration(labelText:widget.ko?'자동 삭제':'Auto-delete'),items:[DropdownMenuItem(value:'off',child:Text(widget.ko?'끄기':'Off')),DropdownMenuItem(value:'1h',child:Text(widget.ko?'1시간':'1 hour')),DropdownMenuItem(value:'24h',child:Text(widget.ko?'24시간':'24 hours')),DropdownMenuItem(value:'7d',child:Text(widget.ko?'7일':'7 days'))],onChanged:(v){if(v!=null){setState(()=>expiry=v);setSheet((){});}})],
      const SizedBox(height:16),SizedBox(width:double.infinity,child:FilledButton(onPressed:()=>Navigator.pop(ctx),child:Text(widget.ko?'완료':'Done')))
    ]))));
  }

  void _reviewPages() { showModalBottomSheet(context:context,builder:(ctx)=>SafeArea(child:ListView.builder(shrinkWrap:true,itemCount:pages.length,itemBuilder:(_,i)=>ListTile(leading:CircleAvatar(child:Text('${i+1}')),title:Text(widget.ko?'페이지 ${i+1}':'Page ${i+1}'),subtitle:Text(pages[i].ocrText.isEmpty?(widget.ko?'텍스트 없음':'No text'):pages[i].ocrText,maxLines:2,overflow:TextOverflow.ellipsis),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:(){setState(()=>pages.removeAt(i));Navigator.pop(ctx);}))))); }
}

class ProcessedScan {
  ProcessedScan(this.path,this.ocrText,this.sensitiveFound);
  final String path,ocrText; final bool sensitiveFound;
}

class ScanProcessor {
  static Future<ProcessedScan> process(String source,{required ScanMode mode,required ScanFilter filter}) async {
    final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
    RecognizedText recognized;
    try { recognized = await recognizer.processImage(InputImage.fromFilePath(source)); } finally { recognizer.close(); }
    final input = await File(source).readAsBytes(); var image = img.decodeImage(input); if(image==null) return ProcessedScan(source,recognized.text,false);
    if(filter==ScanFilter.enhance) image = img.adjustColor(image, contrast:1.22, saturation:0.92);
    if(filter==ScanFilter.mono) image = img.grayscale(image);
    bool sensitive=false;
    final safeText=<String>[];
    for(final block in recognized.blocks){ for(final line in block.lines){ for(final e in line.elements){ final hit=SensitiveDetector.isSensitive(e.text); if(hit) sensitive=true; if(mode==ScanMode.secure && hit){ final r=e.boundingBox; final pad=math.max(6,(r.height*.18).round()); img.fillRect(image,x1:math.max(0,r.left.floor()-pad),y1:math.max(0,r.top.floor()-pad),x2:math.min(image.width-1,r.right.ceil()+pad),y2:math.min(image.height-1,r.bottom.ceil()+pad),color:img.ColorRgb8(18,18,18)); } else { safeText.add(e.text); } } } }
    final out='${source}_processed.jpg'; await File(out).writeAsBytes(img.encodeJpg(image,quality:90),flush:true);
    return ProcessedScan(out,safeText.join(' '),sensitive);
  }

  static Future<Uint8List> buildPdf(List<CapturedPage> pages,{required ScanMode mode,required String watermark,required bool ko}) async {
    final doc=pw.Document(compress:true);
    if(mode==ScanMode.id){
      final front=pw.MemoryImage(await File(pages[0].path).readAsBytes()); final back=pw.MemoryImage(await File(pages[1].path).readAsBytes());
      final date=DateTime.now(); final dateText='${date.year}.${date.month.toString().padLeft(2,'0')}.${date.day.toString().padLeft(2,'0')}'; final mark='${watermark.trim().isEmpty?(ko?'신분증 사본':'ID COPY'):watermark.trim()}  $dateText';
      doc.addPage(pw.Page(pageFormat:PdfPageFormat.a4,margin:const pw.EdgeInsets.all(26),build:(_)=>pw.Stack(children:[pw.Column(children:[pw.Expanded(child:pw.Image(front,fit:pw.BoxFit.contain)),pw.SizedBox(height:12),pw.Divider(),pw.SizedBox(height:12),pw.Expanded(child:pw.Image(back,fit:pw.BoxFit.contain))]),...List.generate(12,(i)=>pw.Positioned(left:(i%3)*170.0-25,top:(i~/3)*210.0+30,child:pw.Transform.rotate(angle:-.55,child:pw.Text(mark,style:pw.TextStyle(fontSize:14,color:PdfColor(0.78,0.43,0.05,.28))))))])));
    } else {
      for(final p in pages){ final mem=pw.MemoryImage(await File(p.path).readAsBytes()); doc.addPage(pw.Page(pageFormat:PdfPageFormat.a4,margin:pw.EdgeInsets.zero,build:(_)=>pw.Stack(children:[pw.Positioned.fill(child:pw.Image(mem,fit:pw.BoxFit.contain)),if(p.ocrText.trim().isNotEmpty)pw.Positioned(left:4,bottom:3,child:pw.Opacity(opacity:.01,child:pw.Text(p.ocrText,style:const pw.TextStyle(fontSize:3))))]))); }
    }
    return Uint8List.fromList(await doc.save());
  }
}

class SensitiveDetector {
  static final email=RegExp(r'^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$',caseSensitive:false);
  static final ssn=RegExp(r'^\d{3}-?\d{2}-?\d{4}$');
  static final rrn=RegExp(r'^\d{6}-?[1-4]\d{6}$');
  static final iban=RegExp(r'^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$');
  static final phone=RegExp(r'^\+?\d[\d\s().-]{7,}\d$');
  static final mrz=RegExp(r'^[A-Z0-9<]{20,44}$');
  static bool isSensitive(String text){ final t=text.trim(); if(t.isEmpty)return false; if(email.hasMatch(t)||ssn.hasMatch(t)||rrn.hasMatch(t)||iban.hasMatch(t)||phone.hasMatch(t)||mrz.hasMatch(t))return true; final digits=t.replaceAll(RegExp(r'[^0-9]'),''); return digits.length>=13&&digits.length<=19&&_luhn(digits); }
  static bool _luhn(String s){ var sum=0; var alt=false; for(var i=s.length-1;i>=0;i--){ var n=int.parse(s[i]); if(alt){n*=2;if(n>9)n-=9;}sum+=n;alt=!alt;}return sum%10==0; }
}

class NativeBridge {
  static const _ch=MethodChannel('org.safescan/native');
  static Future<void> setSecure(bool value)=>_ch.invokeMethod('setSecure',{'value':value});
  static Future<Uint8List> encrypt(Uint8List bytes) async => (await _ch.invokeMethod<Uint8List>('encrypt',bytes))!;
  static Future<Uint8List> decrypt(Uint8List bytes) async => (await _ch.invokeMethod<Uint8List>('decrypt',bytes))!;
  static Future<void> savePdf(Uint8List bytes,String name)=>_ch.invokeMethod('savePdf',{'bytes':bytes,'name':name});
  static Future<void> sharePdf(Uint8List bytes,String name)=>_ch.invokeMethod('sharePdf',{'bytes':bytes,'name':name});
}

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key,required this.prefs,required this.ko,required this.onBack,required this.onLanguageChanged});
  final SharedPreferences prefs; final bool ko; final VoidCallback onBack; final ValueChanged<bool> onLanguageChanged;
  @override State<SettingsScreen> createState()=>_SettingsScreenState();
}
class _SettingsScreenState extends State<SettingsScreen>{
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(leading:IconButton(onPressed:widget.onBack,icon:const Icon(Icons.arrow_back)),title:Text(widget.ko?'설정':'Settings')),body:ListView(padding:const EdgeInsets.all(16),children:[
    Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:const Color(0xFF238B63).withValues(alpha:.12),borderRadius:BorderRadius.circular(18),border:Border.all(color:const Color(0xFF238B63).withValues(alpha:.28))),child:Row(children:[const Icon(Icons.verified_user_outlined,color:Color(0xFF238B63)),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(widget.ko?'인터넷 권한 없음':'No internet permission',style:const TextStyle(fontWeight:FontWeight.w800)),const SizedBox(height:3),Text(widget.ko?'Android 설정 → 앱 → SafeScan → 권한에서 CAMERA만 허용되어 있는지 확인할 수 있습니다.':'Verify under Android Settings → Apps → SafeScan → Permissions. Only CAMERA is requested.',style:Theme.of(context).textTheme.bodySmall)]))])),
    const SizedBox(height:18),SwitchListTile(contentPadding:EdgeInsets.zero,title:Text(widget.ko?'한국어':'Korean'),subtitle:Text(widget.ko?'끄면 영어로 표시됩니다.':'Turn off to use English.'),value:widget.ko,onChanged:widget.onLanguageChanged),
    const Divider(),ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.lock_outline),title:Text(widget.ko?'앱 잠금 PIN':'App lock PIN'),subtitle:Text(widget.prefs.getString('pin')?.isNotEmpty==true?(widget.ko?'설정됨':'Enabled'):(widget.ko?'사용 안 함':'Off')),trailing:const Icon(Icons.chevron_right),onTap:_setPin),
    const Divider(),ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.security_outlined),title:Text(widget.ko?'권한 정책':'Permission policy'),subtitle:Text(widget.ko?'CAMERA만 요청 · 저장소/인터넷 권한 없음':'CAMERA only · no storage or internet permission')),
    const SizedBox(height:22),Text(widget.ko?'보안 구현':'Security implementation',style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.w800)),const SizedBox(height:8),Text(widget.ko?'보안/신분증 문서는 AES-GCM으로 암호화되며 키는 Android Keystore 내부에서 생성되어 앱 밖으로 노출되지 않습니다. 보안 모드에서는 FLAG_SECURE가 활성화됩니다.':'Secure and ID documents use AES-GCM with a key generated inside Android Keystore. FLAG_SECURE is enabled in secure modes.',style:TextStyle(height:1.5,color:Theme.of(context).colorScheme.onSurfaceVariant)),
  ]));
  Future<void> _setPin() async{ final c=TextEditingController(); final v=await showDialog<String>(context:context,builder:(_)=>AlertDialog(title:Text(widget.ko?'PIN 설정':'Set PIN'),content:TextField(controller:c,keyboardType:TextInputType.number,maxLength:6,obscureText:true,decoration:InputDecoration(hintText:widget.ko?'4~6자리 숫자':'4–6 digits')),actions:[TextButton(onPressed:(){widget.prefs.remove('pin');Navigator.pop(context,'');},child:Text(widget.ko?'해제':'Disable')),FilledButton(onPressed:()=>Navigator.pop(context,c.text),child:Text(widget.ko?'저장':'Save'))])); if(v!=null){ if(v.isEmpty||(RegExp(r'^\d{4,6}$').hasMatch(v))){await widget.prefs.setString('pin',v);if(mounted)setState((){});} } }
}

class PinScreen extends StatefulWidget{const PinScreen({super.key,required this.ko,required this.expectedPin,required this.onSuccess});final bool ko;final String expectedPin;final VoidCallback onSuccess;@override State<PinScreen> createState()=>_PinScreenState();}
class _PinScreenState extends State<PinScreen>{final c=TextEditingController();String? error;@override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:Center(child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:360),child:Padding(padding:const EdgeInsets.all(28),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.shield_lock_outlined,size:58),const SizedBox(height:18),Text(widget.ko?'SafeScan 잠금':'SafeScan locked',style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.w800)),const SizedBox(height:18),TextField(controller:c,autofocus:true,obscureText:true,keyboardType:TextInputType.number,maxLength:6,onSubmitted:(_)=>check(),decoration:InputDecoration(labelText:'PIN',errorText:error,border:const OutlineInputBorder())),const SizedBox(height:8),SizedBox(width:double.infinity,child:FilledButton(onPressed:check,child:Text(widget.ko?'잠금 해제':'Unlock')))]))))));void check(){if(c.text==widget.expectedPin)widget.onSuccess();else setState(()=>error=widget.ko?'PIN이 올바르지 않습니다.':'Incorrect PIN');}}
