package org.safescan.safescan

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.view.WindowManager
import androidx.core.content.FileProvider
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class MainActivity : FlutterActivity() {
    private val channelName = "org.safescan/native"
    private val keyAlias = "SafeScanDocumentKeyV1"
    private val createPdfRequest = 5101
    private var pendingSaveBytes: ByteArray? = null
    private var pendingSaveResult: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result -> handleCall(call, result) }
    }

    private fun handleCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "setSecure" -> {
                val value = call.argument<Boolean>("value") ?: false
                if (value) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
                result.success(null)
            }
            "encrypt" -> {
                try {
                    val input = call.arguments as? ByteArray ?: ByteArray(0)
                    result.success(encrypt(input))
                } catch (t: Throwable) {
                    result.error("encrypt_failed", t.message, null)
                }
            }
            "decrypt" -> {
                try {
                    val input = call.arguments as? ByteArray ?: ByteArray(0)
                    result.success(decrypt(input))
                } catch (t: Throwable) {
                    result.error("decrypt_failed", t.message, null)
                }
            }
            "savePdf" -> {
                val bytes = call.argument<ByteArray>("bytes")
                val name = sanitizeName(call.argument<String>("name") ?: "SafeScan.pdf")
                if (bytes == null) {
                    result.error("missing_bytes", "No PDF bytes supplied", null)
                    return
                }
                if (pendingSaveResult != null) {
                    result.error("save_busy", "Another save request is active", null)
                    return
                }
                pendingSaveBytes = bytes
                pendingSaveResult = result
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_TITLE, if (name.endsWith(".pdf", true)) name else "$name.pdf")
                }
                startActivityForResult(intent, createPdfRequest)
            }
            "sharePdf" -> {
                try {
                    val bytes = call.argument<ByteArray>("bytes")
                    val name = sanitizeName(call.argument<String>("name") ?: "SafeScan.pdf")
                    if (bytes == null) {
                        result.error("missing_bytes", "No PDF bytes supplied", null)
                        return
                    }
                    sharePdf(bytes, name)
                    result.success(null)
                } catch (t: Throwable) {
                    result.error("share_failed", t.message, null)
                }
            }
            else -> result.notImplemented()
        }
    }

    @Deprecated("Deprecated in Android API but retained for ACTION_CREATE_DOCUMENT compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != createPdfRequest) return
        val result = pendingSaveResult
        val bytes = pendingSaveBytes
        pendingSaveResult = null
        pendingSaveBytes = null
        if (resultCode != Activity.RESULT_OK || data?.data == null || bytes == null) {
            result?.success(null)
            return
        }
        try {
            contentResolver.openOutputStream(data.data!!, "w")!!.use { it.write(bytes) }
            result?.success(null)
        } catch (t: Throwable) {
            result?.error("save_failed", t.message, null)
        }
    }

    private fun getOrCreateKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(keyAlias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                keyAlias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    private fun encrypt(input: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val iv = cipher.iv
        val ciphertext = cipher.doFinal(input)
        return byteArrayOf(1, iv.size.toByte()) + iv + ciphertext
    }

    private fun decrypt(input: ByteArray): ByteArray {
        require(input.size > 14 && input[0].toInt() == 1) { "Unsupported encrypted payload" }
        val ivSize = input[1].toInt() and 0xFF
        require(ivSize in 12..16 && input.size > 2 + ivSize) { "Invalid encrypted payload" }
        val iv = input.copyOfRange(2, 2 + ivSize)
        val ciphertext = input.copyOfRange(2 + ivSize, input.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(ciphertext)
    }

    private fun sharePdf(bytes: ByteArray, rawName: String) {
        val dir = File(cacheDir, "shares").apply { mkdirs() }
        dir.listFiles()?.forEach { if (it.isFile) it.delete() }
        val name = if (rawName.endsWith(".pdf", true)) rawName else "$rawName.pdf"
        val file = File(dir, name).apply { writeBytes(bytes) }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "Share PDF"))
    }

    private fun sanitizeName(input: String): String {
        val cleaned = input.replace(Regex("[\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim()
        return cleaned.take(96).ifBlank { "SafeScan.pdf" }
    }
}
